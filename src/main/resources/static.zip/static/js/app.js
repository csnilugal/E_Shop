const API_BASE = 'http://localhost:8080';

// Utility for fetching
async function apiFetch(endpoint, options = {}) {
    const user = JSON.parse(localStorage.getItem('user'));
    
    const headers = {
        ...options.headers
    };
    
    if (!(options.body instanceof FormData)) {
        if (!headers['Content-Type']) {
            headers['Content-Type'] = 'application/json';
        }
    }
    
    if (user) {
        headers['X-User-Id'] = user.id;
    }

    const response = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers
    });

    if (!response.ok) {
        let msg = 'API Error';
        try { msg = await response.text(); } catch(e) {}
        throw new Error(msg);
    }
    
    // Check if response is JSON
    const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
        return response.json();
    }
    return response.text();
}

function checkAuth(requireRole = null) {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) {
        window.location.href = '/login.html';
        return null;
    }
    if (requireRole && user.role !== requireRole) {
        if (user.role === 'OWNER') window.location.href = '/admin.html';
        else window.location.href = '/products.html';
        return null;
    }
    
    // Setup nav based on role
    setupNav(user);
    return user;
}

function setupNav(user) {
    const navLinks = document.getElementById('navLinks');
    if (!navLinks) return;
    
    navLinks.innerHTML = '';
    
    if (user.role === 'CUSTOMER') {
        navLinks.innerHTML += `<a href="/products.html">Products</a>`;
        navLinks.innerHTML += `<a href="/cart.html">Cart</a>`;
        navLinks.innerHTML += `<a href="/orders.html">Orders</a>`;
    } else if (user.role === 'OWNER') {
        navLinks.innerHTML += `<a href="/admin.html">Dashboard</a>`;
    }
    
    const logoutBtn = document.createElement('button');
    logoutBtn.id = 'logoutBtn';
    logoutBtn.textContent = 'Logout';
    logoutBtn.onclick = () => {
        localStorage.removeItem('user');
        window.location.href = '/login.html';
    };
    navLinks.appendChild(logoutBtn);
}

function showAlert(message, isError = false) {
    const alertDiv = document.getElementById('alertMsg');
    if (!alertDiv) return;
    
    alertDiv.textContent = message;
    alertDiv.className = `alert ${isError ? 'alert-error' : 'alert-success'}`;
    alertDiv.style.display = 'block';
    
    setTimeout(() => {
        alertDiv.style.display = 'none';
    }, 3000);
}
